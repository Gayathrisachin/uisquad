import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './auth-guard.service';
import { AdminComponent } from './admin/admin.component';
import { MarkAttendanceComponent } from './mark-attendance/mark-attendance.component';
import { ScheduleComponent } from './mark-attendance/schedule/schedule.component';
import { ApplyLeaveComponent } from './mark-attendance/apply-leave/apply-leave.component';
import { LogInfoComponent } from './mark-attendance/log-info/log-info.component';


const routes: Routes = [ 
  { path: '', pathMatch: 'full', redirectTo: 'login'},
  { path: 'login', component: LoginComponent },
  { path: 'mark-attendance', component: MarkAttendanceComponent, canActivate: [AuthGuard] },
  { path: 'schedule', component: ScheduleComponent },
  { path: 'leave', component: ApplyLeaveComponent },
  { path: 'log', component: LogInfoComponent }
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
