import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';


import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { AdminComponent } from './admin/admin.component';
import { MarkAttendanceComponent } from './mark-attendance/mark-attendance.component';
import { ScheduleComponent } from './mark-attendance/schedule/schedule.component';
import { ApplyLeaveComponent } from './mark-attendance/apply-leave/apply-leave.component';
import { LogInfoComponent } from './mark-attendance/log-info/log-info.component'
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AdminComponent,
    MarkAttendanceComponent,
    ScheduleComponent,
    ApplyLeaveComponent,
    LogInfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
