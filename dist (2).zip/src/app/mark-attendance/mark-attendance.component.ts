import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-mark-attendance',
  templateUrl: './mark-attendance.component.html',
  styleUrls: ['./mark-attendance.component.css']
})
export class MarkAttendanceComponent implements OnInit {
  today= new Date();
  todaysDataTime = '';
  constructor(private router:Router) {
    this.todaysDataTime = formatDate(this.today, 'hh:mm:ss a', 'en-US', '+0530');
   }

  ngOnInit(): void {
  }
  onClick(){
    this.router.navigateByUrl('/schedule');
  }
 
 
}
